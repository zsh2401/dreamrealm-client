# LexShino-Shaders-Remade

It's a Shader for Minecraft 1.13.X to 1.14.X
create by Shino Neiluj and LexBoosT

# How to Use DirtyIMG


Français:


1- Ouvrir le Zip du Shader

2- Glissez et déposez le dossier DirtyIMG sur votre bureau.

3- Sélectionnez l'image souhaitée dans DirtyIMG et copiez-la dans le zip du shader à cet emplacement: shaders/lib/IMG/*

4- Remplacez, fermez et enregistrez le Zip et rechargez le shader

5- Prenez plaisir


English:


1- Open your Zip Shader

2- Drag and Drop DirtyIMG folder on your desktop

3- Select the image you want in DirtyIMG and copy it into the shader zip at this location: shaders/lib/IMG/*

4- Remplace and close and save the Zip and reload shader

5- Enjoy